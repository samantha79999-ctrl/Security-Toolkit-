﻿# Security Toolkit v1.2.0

Security Toolkit is a lightweight Windows desktop app that brings together useful security utilities in one place.

## Features
- Password generator with presets, strength breakdown, and improvement suggestions
- Text hash generator and checker
- File hash tool
- Data breach checker
- AES encrypt/decrypt
- Secure notes
- Random data tools
- Persistent local saved history with search/filter
- Export tools for individual results and full history

## Recommended download
Download `Security-Toolkit-1.2.0.zip` for the cleanest install experience.

## Notes
- History is stored locally on the device.
- Password history is masked by default in the UI.
- Windows SmartScreen may show a warning because the app is unsigned.
