﻿Security Toolkit v1.1.0

Security Toolkit is a lightweight Windows desktop app for common security utilities in one place.

Features
- Password generator with presets and strength breakdown
- Hash generator and checker
- Data breach checker
- AES encrypt/decrypt
- Persistent local saved history
- Export tools for individual results and full history

Notes
- History is stored locally on the device
- Password history is masked by default in the UI
- Windows may show a SmartScreen warning because the app is unsigned

Included Files
- Security Toolkit.exe
- README.txt
- LICENSE.txt
- CHANGELOG.txt
- app_icon.png
