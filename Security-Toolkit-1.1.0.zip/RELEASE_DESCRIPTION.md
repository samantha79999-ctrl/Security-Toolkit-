﻿# Security Toolkit v1.1.0

Security Toolkit is a lightweight Windows desktop app that brings together useful security utilities in one place.

## Features
- Password generator with presets and strength breakdown
- Hash generator and checker
- Data breach checker
- AES encrypt/decrypt
- Persistent local saved history
- Export tools for individual results and full history

## Download
Download the packaged ZIP or the standalone EXE from the release assets.

## Notes
- History is stored locally on the device.
- Password history is masked by default in the UI.
- Windows SmartScreen may show a warning because the app is unsigned.
